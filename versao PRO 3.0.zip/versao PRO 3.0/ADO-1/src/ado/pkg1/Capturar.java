/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ado.pkg1;

public class Capturar {

    // Variaveis...
    private static float total = 0;
    private static float totalDaRegiao ;
    private static final String[] estados = new String[27];
    private static final float[] digitos = new float[27];
    private static int index = 0;

    // Metodos...
    // Armazena os numeros, converte e agrega a variavel total 
    public static void armazenarDigitos(String[] vetor) {

        String valor = vetor[1];
        digitos[index] = Float.parseFloat(vetor[1]);
        total += Float.parseFloat(valor);

    }
    
// Armazena os estados ja separados dos numero
    public static void armazenarEstados(String[] vetor) {

        // Variavel index controla o preenchimento do vetor
        estados[index] = vetor[0];
        index++;

    }
// Verifica a regiao no vetor e salva e soma a quantidade.
    public static void verificaRegioes(String linha) {

        for (int i = 0; i < estados.length; i++) {

            if (linha.equals(estados[i])) {

                totalDaRegiao += digitos[i];
            }
            
        }

    }
    
    
     public static void setTotalDaRegiao(float totalDaRegiao) {
         
        Capturar.totalDaRegiao = totalDaRegiao;
    }

    // METODOS para retornar os valores que ja foram tratados....
    
     public static float retornarTotalDaRegiao() {
         
        return totalDaRegiao;
    }

    public static float retornarTotal() {

        return total;
    }

    public static float[] retornarDigitos() {

        return digitos;
    }

    public static String[] retornarEstados() {

        return estados;
    }

}
