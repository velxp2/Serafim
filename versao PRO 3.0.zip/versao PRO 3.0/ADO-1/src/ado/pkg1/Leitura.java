package ado.pkg1;

import java.io.*;

/**
 * Class Description . . .
 *
 * @author: Matheus F Borges
 * @version: 2.0 Main Class File: topAXX.java File: Structure.java
 * Date:19/08/2018
 */
public class Leitura {

    public static void main(String[] args) {
        System.out.println("*********************************************");

        // Variaveis
        String pib = "pib.txt";
        String linha = null;
        String[] estados = null;

        /*      ------------------------------------- */
        /*      Abertura de arquivo e loop de leitura */
        /*      ------------------------------------- */
        try {
            FileReader fileReader = new FileReader(pib);

            BufferedReader bufferedReader = new BufferedReader(fileReader);

            // loop por cada linha do arquivo
            while ((linha = bufferedReader.readLine()) != null) {

                // separa os digito dos estados / Captura separadamente
                // e armazena na classe capturar
                estados = linha.split(";");
                Capturar.armazenarDigitos(estados);
                Capturar.armazenarEstados(estados);
            }
            // fecha o arquivo de leitura
            bufferedReader.close();
            
        } catch (FileNotFoundException ex) {
            System.out.println("Arquivo inexistente: '" + pib + "'");
        } catch (IOException ex) {
            System.out.println("Erro lendo o arquivo '" + pib + "'");
        }

        // Apos ler o arquivo pib, armazena cada cidade e digitos em vetores  
        String[] exibirEstados = Capturar.retornarEstados();
        float[] exibirDigitos = Capturar.retornarDigitos();
        
        // variavel total recebe a soma do pib de todas cidades.
        float total = Capturar.retornarTotal();

        // Impressão do resultado já em percentual
        for (int i = 0; i < exibirEstados.length; i++) {

            System.out.println(exibirEstados[i] + " | "  + (exibirDigitos[i] * 100) / total);
        }
        
        System.out.println("*********************************************");

        
        String regioes = "regioes.txt";

        try {
            FileReader fileReader2 = new FileReader(regioes);

            BufferedReader bufferedReader2 = new BufferedReader(fileReader2);

            while ((linha = bufferedReader2.readLine()) != null) {

                // Verifica se a linha lida nesse momento e igual algum estado 
                // armazenado na classe Capturar
                Capturar.verificaRegioes(linha);

                // Se hover espaço sem texto...
                if (linha.equals("")) {

                    // Guarda o total da região atual e envia para classe 
                    // de Gravação que cuida de gerar a saida.txt
                    float regiao = Capturar.retornarTotalDaRegiao();
                    Gravaçao.escritaEmArquvo(regiao);

                    // Zerandoo total da região para iniciar c contagem novamente
                    Capturar.setTotalDaRegiao(0);
                }

            }

            bufferedReader2.close();
            
        } catch (FileNotFoundException ex) {
            System.out.println("Arquivo inexistente: '" + regioes + "'");
        } catch (IOException ex) {
            System.out.println("Erro lendo o arquivo '" + regioes + "'");
        }
        
        // Apos verificar o arquivo, chama a classe de Gravação.
        Gravaçao.criarArquivoTxt();

    }

}
